//
//  main.m
//  SaoDongMapNode
//
//  Created by songjc on 16/9/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

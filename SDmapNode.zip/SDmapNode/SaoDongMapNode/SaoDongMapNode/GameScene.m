//
//  GameScene.m
//  SaoDongMapNode
//
//  Created by songjc on 16/9/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "GameScene.h"

#import "SDmapNode.h"

@implementation GameScene

-(void)didMoveToView:(SKView *)view{

    [super didMoveToView:view];
//    
//    SDmapNode *mapNode = [[SDmapNode alloc]initWithAtlasName:@"map" tileSize:CGSizeMake(16, 16) tileCodes:[self tileCodesArray]];
    
//    SDmapNode *mapNode = [[SDmapNode alloc]initWithTextFileName:@"background"];
    
    
    SDmapNode *mapNode = [[SDmapNode alloc]initWithTMLFileName:@"map.tmx"];
    
 
    mapNode.position = CGPointMake(self.size.width/2, self.size.height/2);
    
    [self addChild:mapNode];

}

//地图的二维数组
-(NSArray *)tileCodesArray{


    return @[@"xwxxx",
             @"xqqqx",
             @"xooox",
             @"xooox",
             @"xooox"
             
             ];



}




@end

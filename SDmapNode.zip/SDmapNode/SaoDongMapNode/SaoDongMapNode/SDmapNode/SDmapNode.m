//
//  SDmapNode.m
//  SaoDongMapNode
//
//  Created by songjc on 16/9/2.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "SDmapNode.h"
#import <CoreGraphics/CoreGraphics.h>
#import "JSTileMap.h"


@interface SDmapNode ()

@property(nonatomic,strong)SKTextureAtlas *atlas;//用来保存纹理集

@end

@implementation SDmapNode


/************************根据数组形式形式加载瓦片地图***************************/


-(instancetype)initWithAtlasName:(NSString *)atlasName tileSize:(CGSize)tileSize tileCodes:(NSArray*)tileCodes{

    if (self = [super init]) {
        
        
        self.tileSize = tileSize;
        
        self.atlas = [SKTextureAtlas atlasNamed:atlasName];
        
        for (int row = 0; row <tileCodes.count; row ++) {
            
            //获取到每一行的排列字符串.
            NSString *lineString = tileCodes[row];
            
            for (int col = 0; col <lineString.length; col ++) {
                
                //截取指定的字符
                NSString *tileCodeString = [lineString substringWithRange:NSMakeRange(col, 1)];
                
                //创建瓦片
                SKSpriteNode *tileCode = [self nodeForCode:tileCodeString];
                
                //设置瓦片位置
                tileCode.position = [self positionWithRow:row col:col];
                
                
                [self addChild:tileCode];
                
            }
            
            
            
        }
        
        
        
    }
    
    return self;

}

#pragma mark ---- 获取对应的瓦片 ----

-(SKSpriteNode *)nodeForCode:(NSString *)tileCode{
    
    //如果纹理集合为空,返回空.
    if (nil == self.atlas) {
        
        return nil;
    }
    
    
    // 查看当前的纹理集中是否包含名为tileCode的纹理
    if ([self isIncludeTextureWithTextureName:tileCode]) {
        
        SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[self.atlas textureNamed:tileCode]];
        
        //设置过滤模式
        tile.texture.filteringMode = SKTextureFilteringNearest;
        
        return tile;
        
        
    }else{
        
        
        SKSpriteNode *tile = [SKSpriteNode spriteNodeWithTexture:[SKTexture textureWithImageNamed:@""]];
        
        tile.size = self.tileSize;
        
        return tile;
        
        
    }
    
    
}

#pragma mark --- 根据数组下标返回瓦片的位置信息 ----

-(CGPoint )positionWithRow:(int)row col:(int)col{

    CGFloat x = col *_tileSize.width + _tileSize.width/2;
    
    CGFloat y = row *_tileSize.height + _tileSize.height/2;
    
    return CGPointMake(x, y);

}




#pragma mark ---- 查看当前的纹理集中是否包含名为textureName的纹理 ----
-(BOOL)isIncludeTextureWithTextureName:(NSString *)textureName{


    for (NSString *anyName in self.atlas.textureNames) {
        
        if ([anyName isEqualToString:[NSString stringWithFormat:@"%@.jpg",textureName]]) {
            
            return YES;
        }
        
        
        if ([anyName isEqualToString:[NSString stringWithFormat:@"%@.png",textureName]]) {
            
            return YES;
        }
  
    }

    return NO;

}


/************************根据txt文档形式加载瓦片地图***************************/

-(instancetype)initWithTextFileName:(NSString *)fileName{
    
    //获取txt的文件路径字符串
    NSString *txtPath =[[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    
    //如果不存在路径
    if (nil == txtPath || [txtPath isEqualToString:@""]) {
        
        NSLog(@"txt文件路径不存在!");
        
        return nil;
    }
    
    NSError *error = nil;
    
    //获取文本中的字符串
    NSString *txtContents = [NSString stringWithContentsOfFile:txtPath encoding:NSUTF8StringEncoding error:&error];
    
    
    if (error != nil && txtContents ==nil) {
        
        NSLog(@"获取txt文本内容错误");
        
        return nil;
        
    }
    
    //分割txtContents字符串成数组
    NSArray *txtContentArray = [txtContents componentsSeparatedByString:@"\n"];
    
    //获取纹理集的名称
    NSString *atlasName = txtContentArray[0];
    
    //获取每一个纹理的宽度和高度
    NSArray *tileSizeArray = [txtContentArray[1] componentsSeparatedByString:@"*"];
    
    int tileWidth = [tileSizeArray[0] intValue];
    
    int tileHeight = [tileSizeArray.lastObject intValue];
    
    CGSize tileSize =CGSizeMake(tileWidth, tileHeight);
    
    //获取瓦片地图排列组合
    NSArray *tileCodes = [txtContentArray subarrayWithRange:NSMakeRange(2, txtContentArray.count-2)];
    
    
    if (self = [super init]) {
        
        
        self.tileSize = tileSize;
        
        self.atlas = [SKTextureAtlas atlasNamed:atlasName];
        
        for (int row = 0; row <tileCodes.count; row ++) {
            
            //获取到每一行的排列字符串.
            NSString *lineString = tileCodes[row];
            
            for (int col = 0; col <lineString.length; col ++) {
                
                //截取指定的字符
                NSString *tileCodeString = [lineString substringWithRange:NSMakeRange(col, 1)];
                
                //创建瓦片
                SKSpriteNode *tileCode = [self nodeForCode:tileCodeString];
                
                //设置瓦片位置
                tileCode.position = [self positionWithRow:row col:col];
                
                
                [self addChild:tileCode];
                
            }
            
            
            
        }

    }else{
    
    
        NSLog(@"txt形式地图创建失败");
    
    
    }
        
    

    return self;


}


/**********************根据TML文件加载瓦片地图****************************/

-(instancetype)initWithTMLFileName:(NSString *)TMLFileName{

    if (self = [super init]) {
      
        JSTileMap *tileMap = [JSTileMap mapNamed:TMLFileName];
        
        self.mapSize = tileMap.mapSize;
        
        self.tileSize = tileMap.tileSize;
        
        [self addChild:tileMap];
    }

    return self;

}



@end

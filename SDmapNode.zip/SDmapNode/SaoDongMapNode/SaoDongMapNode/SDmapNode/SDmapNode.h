//
//  SDmapNode.h
//  SaoDongMapNode
//
//  Created by songjc on 16/9/2.
//  Copyright © 2016年 Don9. All rights reserved.
//  SpriteKit笔记地址(简书):http://www.jianshu.com/notebooks/5282436/latest
//  作者联系方式(QQ): 676758285


#import <SpriteKit/SpriteKit.h>

@interface SDmapNode : SKSpriteNode



/**
 瓦片的大小
 */
@property (assign, nonatomic) CGSize tileSize;



/**
 @author Don9
 
 使用一个矩阵数组来创建瓦片地图.注意的是,这个方法的矩阵中的纹理图片格式可以为png和jpg格式.
 
 @param atlasName 纹理集合的名称,纹理集里面包含着瓦片地图的瓦片纹理
 @param tileSize  瓦片地图的每一个瓦片的大小(像素点)
 @param tileCodes 瓦片地图的矩阵数组
 
 @return 瓦片地图
 */

-(instancetype)initWithAtlasName:(NSString *)atlasName tileSize:(CGSize)tileSize tileCodes:(NSArray*)tileCodes;



/************************根据txt文档形式加载瓦片地图***************************/


/**
 @author Don9
 
 使用一个txt文件加载一个瓦片地图
 
 @param fileName txt文件名称
 
 @return 瓦片地图
 */
-(instancetype)initWithTextFileName:(NSString *)fileName;



/**********************根据TML文件加载瓦片地图****************************/


/**
 @author Don9 联系QQ:676758285
 
 根据一个TML文件名称创建瓦片地图
 
 @param TMLFileName TML文件名称
 
 @return 瓦片地图
 */
-(instancetype)initWithTMLFileName:(NSString *)TMLFileName;


/**
 地图的大小(PS:可读属性,只能在TML文件创建瓦片地图的时候才能调取)
 */
@property (assign, nonatomic) CGSize mapSize;


@end
